from src.string_utils import (
    reverse_string,
    count_vowels,
    make_uppercase
)


def test_reverse_string():
    assert reverse_string("hello") == "olleh"


def test_count_vowels():
    assert count_vowels("education") == 5


def test_make_uppercase():
    assert make_uppercase("hello") == "HELLO"
