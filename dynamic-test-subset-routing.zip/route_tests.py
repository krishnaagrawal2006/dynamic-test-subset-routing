import os
import sys
import subprocess

ALL_TESTS = [
    "tests/test_math_utils.py",
    "tests/test_string_utils.py"
]

TEST_MAPPING = {
    "src/math_utils.py": "tests/test_math_utils.py",
    "src/string_utils.py": "tests/test_string_utils.py"
}


def get_changed_files(base, head):
    if not base or set(base) == {"0"}:
        return None

    result = subprocess.run(
        ["git", "diff", "--name-only", base, head],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:
        print("Could not compare commits. Running all tests.")
        return None

    return result.stdout.splitlines()


def select_tests(changed_files):
    if changed_files is None:
        return ALL_TESTS

    selected_tests = set()

    for file in changed_files:
        if file in TEST_MAPPING:
            selected_tests.add(TEST_MAPPING[file])

        elif file in ALL_TESTS:
            selected_tests.add(file)

        else:
            return ALL_TESTS

    if not selected_tests:
        return ALL_TESTS

    return sorted(selected_tests)


def main():
    base = (
        sys.argv[1] if len(sys.argv) > 1
        else os.getenv("BASE_SHA")
    )

    head = (
        sys.argv[2] if len(sys.argv) > 2
        else os.getenv("HEAD_SHA", "HEAD")
    )

    print("DYNAMIC TEST-SUBSET ROUTING STARTED")

    changed_files = get_changed_files(base, head)

    if changed_files is None:
        print("No valid comparison. Running all tests.")
    else:
        print("Changed files:")
        for file in changed_files:
            print("-", file)

    selected_tests = select_tests(changed_files)

    print("\nSelected test files:")
    for test in selected_tests:
        print("-", test)

    print("\nRunning selected tests...")

    result = subprocess.run(
        [sys.executable, "-m", "pytest", "-v"] + selected_tests
    )

    sys.exit(result.returncode)


if __name__ == "__main__":
    main()
