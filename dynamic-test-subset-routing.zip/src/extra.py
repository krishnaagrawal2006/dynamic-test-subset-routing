def sample():
    return "Hello"
